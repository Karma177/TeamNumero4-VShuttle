# V-Shuttle Dashboard

Questo progetto implementa la soluzione per la sfida "Hackaton Pitch & Build - Progetto V-Shuttle" per Waymo LCC.

## Il Problema Risolto
Le navette a guida autonoma di Waymo vanno in panico di fronte a cartelli stradali complessi o degradati. Il nostro sistema risolve questo problema attraverso due componenti principali:
1. **Backend / Logica di Fusione**: Un algoritmo deterministico che riceve dati da 3 sensori (telecamera frontale, laterale e ricevitore V2I), pulisce gli errori OCR comuni e fonde i dati pesando l'affidabilità di ciascun sensore. Successivamente, un parser semantico valuta la presenza di divieti, eccezioni (es. "Eccetto BUS") e vincoli temporali (orari e giorni festivi) per decidere l'azione da intraprendere (GO, STOP o REQUIRE_HUMAN).
2. **Dashboard Live (Frontend)**: Un'interfaccia utente progettata per il "Safety Driver" (Marco) su un tablet da 12 pollici. La dashboard avvia una simulazione continua che scorre gli scenari ogni 4 secondi. In caso di incertezza (`REQUIRE_HUMAN`), il sistema si ferma e offre a Marco esattamente 2 secondi per intervenire tramite pulsanti "Fat Finger" ad alto contrasto. Se il tempo scade, il sistema applica un fallback di sicurezza (STOP).

## Schema Architetturale

```mermaid
graph TD
    A[Scenari JSON] -->|Caricamento| B(Express Backend)
    B --> C{Logica di Fusione}
    C -->|Pulizia OCR| D[Dati Normalizzati]
    D -->|Fusione Ponderata| E[Testo Fuso & Confidenza]
    E --> F{Parser Semantico}
    F -->|Valutazione Regole| G[Azione: GO / STOP / REQUIRE_HUMAN]
    G -->|API REST| H(React Frontend Dashboard)
    H -->|Loop 4s| I[Mostra Risultato]
    I -->|Se REQUIRE_HUMAN| J{Timer 2s}
    J -->|Intervento| K[Azione Manuale]
    J -->|Timeout| L[Fallback STOP]
```

## Logica di Fusione
L'algoritmo di fusione assegna pesi specifici a ciascun sensore:
- Telecamera Frontale: 0.5
- Telecamera Laterale: 0.2
- Ricevitore V2I: 0.8 (Altamente affidabile se presente)

Il testo di ogni sensore viene prima "pulito" da errori OCR comuni (es. "D1V1ET0" -> "DIVIETO"). Successivamente, i testi puliti uguali sommano i loro pesi. Il testo con il peso totale maggiore vince. La confidenza finale è calcolata rapportando il punteggio massimo ottenuto con il peso totale teorico di base.

## Setup Infallibile

Per installare le dipendenze:
```bash
npm install
```

## Run Instructions

Per avviare il server backend e l'applicazione frontend in modalità sviluppo:
```bash
npm run dev
```
L'applicazione sarà disponibile all'indirizzo `http://localhost:3000`.
