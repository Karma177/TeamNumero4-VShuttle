import express from "express";
import { createServer as createViteServer } from "vite";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { evaluateScenario, Scenario } from "./src/backend/logic.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  app.get("/api/scenarios", (req, res) => {
    try {
      const dataPath = path.resolve(__dirname, "src/data/scenarios.json");
      const data = fs.readFileSync(dataPath, "utf-8");
      const scenarios: Scenario[] = JSON.parse(data);
      
      const processed = scenarios.map(scen => {
        const result = evaluateScenario(scen);
        return {
          scenario: scen,
          result
        };
      });
      
      res.json(processed);
    } catch (error) {
      console.error("Error loading scenarios:", error);
      res.status(500).json({ error: "Failed to load scenarios" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static('dist'));
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
