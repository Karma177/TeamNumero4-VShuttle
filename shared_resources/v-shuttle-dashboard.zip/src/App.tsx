import React, { useState, useEffect, useRef } from 'react';
import { Play, AlertTriangle, CheckCircle, XCircle, Hand, ArrowRight } from 'lucide-react';

type ActionType = 'GO' | 'STOP' | 'REQUIRE_HUMAN';

interface ProcessedScenario {
  scenario: {
    id: string;
    current_time: string;
    current_day: string;
    is_holiday: boolean;
  };
  result: {
    action: ActionType;
    reason: string;
    confidence: number;
    fused_text: string;
  };
}

export default function App() {
  const [scenarios, setScenarios] = useState<ProcessedScenario[]>([]);
  const [currentIndex, setCurrentIndex] = useState(-1);
  const [isRunning, setIsRunning] = useState(false);
  const [humanIntervention, setHumanIntervention] = useState(false);
  const [timeLeft, setTimeLeft] = useState(2000); // 2 seconds in ms
  const [finalAction, setFinalAction] = useState<ActionType | null>(null);

  const timerRef = useRef<number | null>(null);
  const loopRef = useRef<NodeJS.Timeout | null>(null);
  const lastUpdateRef = useRef<number>(0);

  useEffect(() => {
    fetch('/api/scenarios')
      .then(res => res.json())
      .then(data => setScenarios(data))
      .catch(err => console.error(err));
  }, []);

  const startSimulation = () => {
    setIsRunning(true);
    setCurrentIndex(0);
    setFinalAction(null);
    setHumanIntervention(false);
  };

  const stopSimulation = () => {
    setIsRunning(false);
    if (loopRef.current) clearTimeout(loopRef.current);
    if (timerRef.current) cancelAnimationFrame(timerRef.current);
  };

  const nextScenario = () => {
    setCurrentIndex(prev => {
      if (prev + 1 >= scenarios.length) {
        stopSimulation();
        return prev;
      }
      return prev + 1;
    });
    setFinalAction(null);
    setHumanIntervention(false);
  };

  useEffect(() => {
    if (!isRunning || currentIndex === -1 || currentIndex >= scenarios.length) return;

    const current = scenarios[currentIndex];
    
    if (current.result.action === 'REQUIRE_HUMAN') {
      setHumanIntervention(true);
      setTimeLeft(2000);
      lastUpdateRef.current = performance.now();
      
      const updateTimer = (timestamp: number) => {
        const delta = timestamp - lastUpdateRef.current;
        lastUpdateRef.current = timestamp;
        
        setTimeLeft(prev => {
          const newTime = prev - delta;
          if (newTime <= 0) {
            handleHumanChoice('STOP'); // Fallback di sicurezza
            return 0;
          }
          timerRef.current = requestAnimationFrame(updateTimer);
          return newTime;
        });
      };
      
      timerRef.current = requestAnimationFrame(updateTimer);
      
    } else {
      setFinalAction(current.result.action);
      loopRef.current = setTimeout(() => {
        nextScenario();
      }, 4000);
    }

    return () => {
      if (loopRef.current) clearTimeout(loopRef.current);
      if (timerRef.current) cancelAnimationFrame(timerRef.current);
    };
  }, [currentIndex, isRunning]);

  const handleHumanChoice = (choice: 'GO' | 'STOP') => {
    if (timerRef.current) cancelAnimationFrame(timerRef.current);
    setHumanIntervention(false);
    setFinalAction(choice);
    
    // Attendiamo 2 secondi per mostrare la scelta prima di passare al prossimo
    loopRef.current = setTimeout(() => {
      nextScenario();
    }, 2000);
  };

  if (scenarios.length === 0) {
    return <div className="flex items-center justify-center h-screen bg-slate-900 text-white">Caricamento scenari...</div>;
  }

  if (!isRunning && currentIndex === -1) {
    return (
      <div className="flex flex-col items-center justify-center h-screen bg-slate-900 text-white p-8">
        <h1 className="text-5xl font-bold mb-8 tracking-tight">V-Shuttle Dashboard</h1>
        <p className="text-xl text-slate-400 mb-12 text-center max-w-2xl">
          Sistema di monitoraggio e intervento per Safety Driver. 
          La simulazione valuterà automaticamente gli scenari.
        </p>
        <button 
          onClick={startSimulation}
          className="flex items-center gap-4 bg-emerald-600 hover:bg-emerald-500 text-white px-12 py-8 rounded-3xl text-3xl font-bold transition-all shadow-lg shadow-emerald-900/50 active:scale-95 cursor-pointer"
        >
          <Play size={40} />
          START SIMULATION
        </button>
      </div>
    );
  }

  const current = scenarios[currentIndex];
  const isFinished = !isRunning && currentIndex >= scenarios.length - 1;

  if (isFinished) {
    return (
      <div className="flex flex-col items-center justify-center h-screen bg-slate-900 text-white p-8">
        <CheckCircle size={80} className="text-emerald-500 mb-8" />
        <h1 className="text-5xl font-bold mb-8">Simulazione Completata</h1>
        <button 
          onClick={startSimulation}
          className="bg-slate-700 hover:bg-slate-600 text-white px-8 py-4 rounded-2xl text-xl font-bold transition-all cursor-pointer"
        >
          Riavvia
        </button>
      </div>
    );
  }

  const getActionColor = (action: ActionType | null) => {
    if (action === 'GO') return 'bg-emerald-500 text-white';
    if (action === 'STOP') return 'bg-red-600 text-white';
    if (action === 'REQUIRE_HUMAN') return 'bg-amber-500 text-slate-900';
    return 'bg-slate-700 text-white';
  };

  const getActionIcon = (action: ActionType | null) => {
    if (action === 'GO') return <ArrowRight size={64} />;
    if (action === 'STOP') return <Hand size={64} />;
    if (action === 'REQUIRE_HUMAN') return <AlertTriangle size={64} />;
    return null;
  };

  return (
    <div className="flex flex-col h-screen bg-slate-950 text-slate-100 overflow-hidden font-sans">
      {/* Header */}
      <header className="flex justify-between items-center p-6 bg-slate-900 border-b border-slate-800">
        <div className="flex items-center gap-4">
          <div className="w-4 h-4 rounded-full bg-emerald-500 animate-pulse"></div>
          <h1 className="text-2xl font-bold tracking-wider">WAYMO V-SHUTTLE LIVE</h1>
        </div>
        <div className="flex gap-6 text-slate-400 font-mono text-lg">
          <div>SCENARIO: {currentIndex + 1}/{scenarios.length}</div>
          <div>TIME: {current.scenario.current_time}</div>
          <div>DAY: {current.scenario.current_day} {current.scenario.is_holiday ? '(FESTIVO)' : ''}</div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex flex-col p-8 gap-8">
        
        {/* Top Section: Sensor Fusion Result */}
        <div className="bg-slate-900 rounded-3xl p-8 border border-slate-800 shadow-xl flex flex-col items-center justify-center flex-1">
          <h2 className="text-slate-400 text-xl font-bold mb-4 uppercase tracking-widest">Lettura Cartello (Fusa)</h2>
          <div className="text-5xl md:text-7xl font-black text-center tracking-tight mb-8">
            {current.result.fused_text || "NESSUN CARTELLO RILEVATO"}
          </div>
          
          <div className="w-full max-w-3xl">
            <div className="flex justify-between text-sm font-bold text-slate-400 mb-2 uppercase">
              <span>Confidenza Sensori</span>
              <span>{Math.round(current.result.confidence * 100)}%</span>
            </div>
            <div className="h-4 bg-slate-800 rounded-full overflow-hidden">
              <div 
                className={`h-full rounded-full transition-all duration-500 ${current.result.confidence > 0.7 ? 'bg-emerald-500' : current.result.confidence > 0.4 ? 'bg-amber-500' : 'bg-red-500'}`}
                style={{ width: `${current.result.confidence * 100}%` }}
              ></div>
            </div>
          </div>
        </div>

        {/* Bottom Section: Action & Intervention */}
        <div className="flex gap-8 h-64">
          
          {/* Action Display */}
          <div className={`flex-1 rounded-3xl flex flex-col items-center justify-center transition-colors duration-300 ${getActionColor(finalAction || current.result.action)}`}>
            {getActionIcon(finalAction || current.result.action)}
            <div className="text-6xl font-black mt-4 tracking-widest">
              {finalAction || current.result.action}
            </div>
            {!humanIntervention && (
              <div className="mt-4 text-lg font-medium opacity-80 text-center px-8">
                {current.result.reason}
              </div>
            )}
          </div>

          {/* Human Intervention Panel */}
          {humanIntervention && (
            <div className="flex-[2] bg-slate-900 rounded-3xl p-6 border-4 border-amber-500 flex flex-col shadow-2xl shadow-amber-900/20 animate-in slide-in-from-bottom-8">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-2xl font-black text-amber-500 flex items-center gap-3 animate-pulse">
                  <AlertTriangle /> INTERVENTO RICHIESTO
                </h3>
                <div className="text-4xl font-mono font-bold text-amber-400">
                  {(timeLeft / 1000).toFixed(1)}s
                </div>
              </div>
              
              <div className="w-full h-2 bg-slate-800 rounded-full mb-6 overflow-hidden">
                <div 
                  className="h-full bg-amber-500 transition-all ease-linear"
                  style={{ width: `${(timeLeft / 2000) * 100}%` }}
                ></div>
              </div>

              <div className="flex gap-4 flex-1">
                <button 
                  onClick={() => handleHumanChoice('STOP')}
                  className="flex-1 bg-red-600 hover:bg-red-500 active:bg-red-700 rounded-2xl text-3xl font-black text-white transition-all shadow-lg active:scale-95 flex flex-col items-center justify-center gap-2 cursor-pointer"
                >
                  <XCircle size={48} />
                  CONFERMA STOP
                </button>
                <button 
                  onClick={() => handleHumanChoice('GO')}
                  className="flex-1 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 rounded-2xl text-3xl font-black text-white transition-all shadow-lg active:scale-95 flex flex-col items-center justify-center gap-2 cursor-pointer"
                >
                  <CheckCircle size={48} />
                  OVERRIDE (GO)
                </button>
              </div>
            </div>
          )}
        </div>

      </main>
    </div>
  );
}
