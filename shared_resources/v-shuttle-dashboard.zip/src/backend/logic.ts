export interface SensorData {
  text: string;
  confidence: number;
}

export interface Scenario {
  id: string;
  current_time: string;
  current_day: string;
  is_holiday: boolean;
  sensors: {
    front_camera: SensorData | null;
    side_camera: SensorData | null;
    V2I_receiver: SensorData | null;
  };
}

export interface ProcessedResult {
  action: 'GO' | 'STOP' | 'REQUIRE_HUMAN';
  reason: string;
  confidence: number;
  fused_text: string;
}

export function cleanOCR(text: string): string {
  if (!text) return "";
  return text.toUpperCase()
    .replace(/0/g, 'O')
    .replace(/1/g, 'I')
    .replace(/4/g, 'A')
    .replace(/5/g, 'S')
    .replace(/8/g, 'B')
    .replace(/D[I1]V[I1]ET[O0]/g, 'DIVIETO')
    .replace(/TR[A4]NS[I1]T[O0]/g, 'TRANSITO')
    .replace(/ECCETT[O0]/g, 'ECCETTO')
    .replace(/FEST[I1]V[I1]/g, 'FESTIVI')
    .replace(/[^A-Z0-9: \-]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function fuseSensors(sensors: Scenario['sensors']): { text: string, confidence: number } {
  const weights = {
    front_camera: 0.5,
    side_camera: 0.2,
    V2I_receiver: 0.8 // V2I is highly reliable if present
  };

  const readings: Record<string, number> = {};
  let totalWeight = 0;

  for (const [sensor, data] of Object.entries(sensors)) {
    if (data && data.text) {
      const cleaned = cleanOCR(data.text);
      const weight = weights[sensor as keyof typeof weights] * data.confidence;
      readings[cleaned] = (readings[cleaned] || 0) + weight;
      totalWeight += weight;
    }
  }

  if (Object.keys(readings).length === 0) {
    return { text: "", confidence: 0 };
  }

  let bestText = "";
  let maxScore = -1;

  for (const [text, score] of Object.entries(readings)) {
    if (score > maxScore) {
      maxScore = score;
      bestText = text;
    }
  }

  // Normalize confidence to 0-1 based on max possible weight
  const maxPossibleWeight = weights.front_camera + weights.side_camera + weights.V2I_receiver;
  const absoluteConfidence = Math.min(1, maxScore / (weights.front_camera + weights.side_camera)); // Using front+side as baseline 1.0

  return { text: bestText, confidence: absoluteConfidence };
}

function isTimeInRange(currentTime: string, rangeStr: string): boolean {
  // rangeStr like "08:00-18:00"
  const match = rangeStr.match(/(\d{2}:\d{2})\s*-\s*(\d{2}:\d{2})/);
  if (!match) return false;
  
  const start = match[1];
  const end = match[2];
  
  return currentTime >= start && currentTime <= end;
}

export function evaluateScenario(scenario: Scenario): ProcessedResult {
  const { text: fusedText, confidence } = fuseSensors(scenario.sensors);

  if (confidence < 0.4 || fusedText === "") {
    return {
      action: 'REQUIRE_HUMAN',
      reason: 'Confidenza sensori troppo bassa o dati assenti',
      confidence,
      fused_text: fusedText || "NESSUN DATO"
    };
  }

  // Semantic Parsing
  const isDivieto = fusedText.includes('DIVIETO') || fusedText.includes('ZTL') || fusedText.includes('STRADA CHIUSA');
  const isEccettoBus = fusedText.includes('ECCETTO BUS') || fusedText.includes('TRANNE BUS') || fusedText.includes('ECCETTO AUTOBUS');
  
  // Time parsing
  const timeMatch = fusedText.match(/\d{2}:\d{2}\s*-\s*\d{2}:\d{2}/);
  let isTimeActive = true; // Default active if no time specified
  if (timeMatch) {
    isTimeActive = isTimeInRange(scenario.current_time, timeMatch[0]);
  }

  // Holiday parsing
  const isFestiviOnly = fusedText.includes('FESTIVI');
  let isDayActive = true;
  if (isFestiviOnly) {
    isDayActive = scenario.is_holiday;
  }

  if (isDivieto) {
    if (isEccettoBus) {
      return {
        action: 'GO',
        reason: 'Divieto presente ma con eccezione per BUS',
        confidence,
        fused_text: fusedText
      };
    }

    if (isTimeActive && isDayActive) {
      return {
        action: 'STOP',
        reason: 'Divieto o ZTL attiva in questo orario/giorno',
        confidence,
        fused_text: fusedText
      };
    } else {
      return {
        action: 'GO',
        reason: 'Divieto o ZTL NON attiva in questo orario/giorno',
        confidence,
        fused_text: fusedText
      };
    }
  }

  // If no explicit prohibition
  if (confidence < 0.6) {
     return {
      action: 'REQUIRE_HUMAN',
      reason: 'Testo ambiguo, confidenza media',
      confidence,
      fused_text: fusedText
    };
  }

  return {
    action: 'GO',
    reason: 'Nessun divieto rilevato',
    confidence,
    fused_text: fusedText
  };
}
